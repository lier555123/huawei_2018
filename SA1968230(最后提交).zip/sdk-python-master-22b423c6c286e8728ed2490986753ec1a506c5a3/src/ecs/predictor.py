import os
import datetime
import math
fac = [0.28,0.28,0.28,0.28,0.28,0.26,0.26,0.26,0.28,0.28,0.28,0.28,0.28,0.28,0.28]

flavor_cpu = {
    1: 1,
    2: 1,
    3: 1,
    4: 2,
    5: 2,
    6: 2,
    7: 4,
    8: 4,
    9: 4,
    10: 8,
    11: 8,
    12: 8,
    13: 16,
    14: 16,
    15: 16
}


flavor_mem = {
    1: 1,
    2: 2,
    3: 4,
    4: 2,
    5: 4,
    6: 8,
    7: 4,
    8: 8,
    9: 16,
    10: 8,
    11: 16,
    12: 32,
    13: 16,
    14: 32,
    15: 64
}


flavor_info = []
flavor_sum_info = ''
predict_time_info = 0
opt_type_info = ''
cpu_sum = 0
mem_sum = 0
disk_sum = 0
sum1 = 0
sum_flavor = []
result = []
weight = []
value = []
tab = []
tab_cnt = []


def transfer_date(input_data_array):
    first_array = []
    second_array = []

    for i in input_data_array:
        [id, first, second, time] = i.split()
        first = first[6:8]
        if int(first) <= 15 and int(first) >= 1:
            first_array.append(int(first))
            date = datetime.datetime.strptime(second, '%Y-%m-%d')
            second_array.append(date)
    print('first_array:', first_array)
    #print('second_array:', second_array)
    return first_array, second_array

def transfer_gap_date(train_date):
    gap_date = []
    for i in range(len(train_date)):
        gap_date.append((train_date[i] - train_date[0]).days)
    print('gap_data = ', gap_date)
    return gap_date

def flavor_type_sum(gap_date, period, flavor):
    matrix = []
    for i in range(15):
        matrix.append([0]*int((gap_date[-1] + period )/period))
    print('matrix:', matrix)
    for i in range(len(flavor)):
        #print('i = ', i)
        if flavor[i] < 16:
            matrix[flavor[i] - 1][int(gap_date[i] / period)] += 1
    #print(matrix)
    return matrix

def predict_flavor(flavor_sum_array, eff):
    avg_flavor = []
    sum = 0
    print(flavor_sum_array)
    for i in range(15):
        # for j in flavor_sum_array[i]:
        #     sum += int(j)
        # #print(sum)
        # sum /= (float)((gap_date[-1] + 2))
        tmp_flavor_sum_array = flavor_sum_array[i]
        sum = (float)(tmp_flavor_sum_array[-1]*0.20 + tmp_flavor_sum_array[-2]*0.20 + tmp_flavor_sum_array[-3]*0.17
                      + tmp_flavor_sum_array[-4]*0.13 + tmp_flavor_sum_array[-5]*0.1 + tmp_flavor_sum_array[-6]*0.1
                      + tmp_flavor_sum_array[-7]*0.06 + tmp_flavor_sum_array[-8]*0.04 )
        #if sum <= 0:
        	#sum = 1.0
        sum = float(sum * fac[i])
        if i == 0:
            sum = sum + 0.0
        avg_flavor.append(sum)
    print(avg_flavor)
    return avg_flavor

def config_info_pro(ecs_infor_array):
    global flavor_sum_info, flavor_info, opt_type_info, cpu_sum, mem_sum, disk_sum, predict_time_info
    print(ecs_infor_array)
    [cpu_sum_tmp, mem_sum_tmp, disk_sum_tmp] = ecs_infor_array[0].split()
    cpu_sum = int(cpu_sum_tmp)
    mem_sum = int(mem_sum_tmp)
    disk_sum = int(disk_sum_tmp)
    index = 1
    while ecs_infor_array[index] == '\r\n':
        index += 1
    print('index=', index)
    flavor_sum_info = ecs_infor_array[index]
    print(flavor_sum_info)
    print(type(flavor_sum_info))
    flavor_sum_info = int(flavor_sum_info)
    index += 1
    for i in ecs_infor_array[index:index+flavor_sum_info]:
        flavor_info.append(int(i[6:8]))
    index += flavor_sum_info
    while ecs_infor_array[index] == '\r\n':
        index += 1
    opt_type_info = ecs_infor_array[index].strip()
    index += 1
    while ecs_infor_array[index] == '\r\n':
        index += 1
    start_time_tmp = ecs_infor_array[index]
    start_time_info = datetime.datetime.strptime(start_time_tmp[0:10], '%Y-%m-%d')
    index += 1
    end_time_tmp = ecs_infor_array[index]
    end_time_info = datetime.datetime.strptime(end_time_tmp[0:10], '%Y-%m-%d')
    predict_time_info = (end_time_info - start_time_info).days
    return


def flavor_resource(sum_flavor):
    flavor_cpu_resource = 0
    flavor_mem_resource = 0
    for i in range(len(flavor_info)):
        flavor_cpu_resource += sum_flavor[i] * flavor_cpu[i + 1]
        flavor_mem_resource += sum_flavor[i] * flavor_mem[i + 1]
    print(flavor_cpu_resource, flavor_mem_resource)
    return flavor_cpu_resource, flavor_mem_resource

def server_need(flavor_cpu_resource, flavor_mem_resource):
    global cpu_sum, mem_sum, opt_type_info
    if opt_type_info == 'CPU':
        server_num = math.ceil(flavor_cpu_resource/cpu_sum)
        print("server_num:", server_num)
        while server_num * mem_sum < flavor_mem_resource:
            server_num += 1
        return server_num
    if opt_type_info == 'MEM':
        server_num = math.ceil(flavor_mem_resource / mem_sum)
        print("server_num:", server_num)
        while server_num * cpu_sum < flavor_cpu_resource:
            server_num += 1
        return server_num

def is_place_over():
    global sum_flavor
    #print(flavor_info)
    #print(sum_flavor)
    for k in flavor_info[::-1]:
        #print(k)
        if int(sum_flavor[k-1]) > 0:
          return 1
    return 0

def pre_process_sum_flavor():
    for i in range(15):
        if (i+1) not in flavor_info:
            sum_flavor[i] = 0
    return 0

def flavor_placing_second(w, v, n, cap, cap2):
    dp = [[0 for i in range(cap+1)] for i in range(n+1)]
    sum_flavor1 = [0 for i in range(15)]
    for i in range(15):
        sum_flavor1[i] = sum_flavor[14-i]
    flag = 0
    res = 0
    for i in range(1, n+1):
        if flag == 1:
            break
        for j in range(1, cap+1):
            if (j - w[i]) >= 0:
                dp[i][j] = max(dp[i-1][j], dp[i-1][j-w[i]]+v[i])
                if dp[i][j] > cap2:
                    dp[i][j] = dp[i-1][j]

                if dp[i][j] == cap2:
                    res = j
                    flag = 1
                    print('dp1 = ', dp[i][j])
                    break
            else:
                dp[i][j] = dp[i - 1][j]
    print('dp = ', dp[n][cap])

    tab = [0 for i in range(n)]
    if flag == 1:
        k = res
    else:
        k = cap
    for i in range(n, 0, -1):
        if dp[i][k] > dp[i-1][k]:
            tab[i - 1] = 1
            k = k - w[i]
    print('tab = ', tab)

    flavor_cnt = [0 for i in range(15)]

    tmp = tab[0:sum_flavor[14]]
    flavor_cnt[14] = tmp.count(1)
    sum_flavor[14] = sum_flavor[14] - flavor_cnt[14]

    print('sum_flavor1 = ', sum_flavor1)
    tmp_sum = sum_flavor1[0]
    for i in range(14):

        left_sum = tmp_sum
        right_sum = tmp_sum + sum_flavor1[i + 1]
        tmp_sum = right_sum
        tmp = tab[left_sum:right_sum]
        flavor_cnt[14-i-1] = tmp.count(1)
        sum_flavor[14-i-1] = sum_flavor[14-i-1] - flavor_cnt[14-i-1]
    print('flavor_cnt = ', flavor_cnt)
    print('sum_flavor = ', sum_flavor)
    return flavor_cnt

def flavor_placing_first():
    n = 0
    for i in range(15):
        n = n + sum_flavor[i]
    w = [0 for i in range(n+1)]
    v = [0 for i in range(n+1)]
    k = 1
    for i in range(14, -1, -1):
        for j in range(sum_flavor[i]):
            w[k] = flavor_mem[i+1]
            v[k] = flavor_cpu[i+1]
            k = k+1
    print('w = ', w)
    print('v = ', v)
    print('n= ', n)
    return w, v, n

def flavor_placing():
    cnt = 0
    pre_process_sum_flavor()
    place_cnt = [0 for x in range(15)]
    while is_place_over():
        str_s = ' '
        [w, v, n] = flavor_placing_first()
        if opt_type_info == 'CPU':
            place_cnt = flavor_placing_second(w, v, n, mem_sum, cpu_sum)
        if opt_type_info == 'MEM':
            place_cnt = flavor_placing_second(v, w, n, cpu_sum, mem_sum)
        for i in range(15):
            if place_cnt[i] > 0:
                str_s = str_s + 'flavor' + str(i + 1) + ' ' + str(place_cnt[i]) + ' '
        result.append(str(cnt+1) + ' ' +str_s)
        #print('str_s = ', str_s)
        cnt = cnt + 1
    return cnt

def predict_vm(ecs_lines, input_lines):
    global sum_flavor
    global result,predict_time_info
    global sum1
    sum1 = 0
    if ecs_lines is None:
        print('ecs information is none')
        return result
    if input_lines is None:
        print('input file information is none')
        return result

    #config_info_pro(ecs_lines)
    config_info_pro(input_lines)
    flavor_info.sort()
    print(cpu_sum, mem_sum, disk_sum, flavor_sum_info, flavor_info, predict_time_info, opt_type_info)
    #[flavor, train_date] = transfer_date(input_lines)
    [flavor, train_date] = transfer_date(ecs_lines)
    gap_date = transfer_gap_date(train_date)
    flavor_sum_array = flavor_type_sum(gap_date, 7, flavor)
    avg_flavor = predict_flavor(flavor_sum_array, 0.36)  

    sum_flavor = [x * predict_time_info for x in avg_flavor]
    sum_flavor = [int(x) for x in sum_flavor] 
    print (sum_flavor)
    for i in flavor_info:
        sum1 += sum_flavor[i - 1]
    print (sum1)
    #sum=int(sum)
    result.append(str(sum1))   
    print(flavor_info)
    str_str=''
    for i in flavor_info:
        i=int(i)
        str_str='flavor'+str(i)+' '+str(int(sum_flavor[i-1]))
        print(str_str)
        result.append('flavor'+str(i)+' '+str(int(sum_flavor[i-1])))  
        #if i == flavor_info[-1]:
           #result.append('\n')
    
    result.append(' ')
    result.append('0')      
    [flavor_cpu_resource, flavor_mem_resource] = flavor_resource(sum_flavor)
    server_num = server_need(flavor_cpu_resource, flavor_mem_resource)
    #print("server_num:", server_num)
    #real_server_num = flavor_placing(server_num, cpu_sum,mem_sum,opt_type_info)
    real_server_num = flavor_placing()
    print(real_server_num)
    #real_server_num=int(real_server_num)
    result[flavor_sum_info+2] = str(real_server_num)
    return result
