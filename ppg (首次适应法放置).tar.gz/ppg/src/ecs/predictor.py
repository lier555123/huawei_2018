import os
import datetime
import math


flavor_cpu = {
    1: 1,
    2: 1,
    3: 1,
    4: 2,
    5: 2,
    6: 2,
    7: 4,
    8: 4,
    9: 4,
    10: 8,
    11: 8,
    12: 8,
    13: 16,
    14: 16,
    15: 16
}


flavor_mem = {
    1: 1,
    2: 2,
    3: 4,
    4: 2,
    5: 4,
    6: 8,
    7: 4,
    8: 8,
    9: 16,
    10: 8,
    11: 16,
    12: 32,
    13: 16,
    14: 32,
    15: 64
}


flavor_info = []
flavor_sum_info = ''
predict_time_info = 0
opt_type_info = ''
cpu_sum = 0
mem_sum = 0
disk_sum = 0
sum_flavor = []
result = []
"""
def transfer_date(input_data_array):
    #result = []
    first_array = []
    second_array = []

    for i in input_data_array:
        result.append(i[20:33])        
        tmp = i[20:33]
        [first, second] = tmp.split()
        first_array.append(int(first))
        date = datetime.datetime.strptime(second, '%Y-%m-%d')
        second_array.append(date)
   # print(first_array)
   # print(second_array)
    return first_array, second_array
"""
def transfer_date(input_data_array):
    first_array = []
    second_array = []

    for i in input_data_array:
        [id, first, second, time] = i.split()
        first = first[6:8]
        if int(first) <= 15 and int(first) >= 1:
        	first_array.append(int(first))
        	date = datetime.datetime.strptime(second, '%Y-%m-%d')
        	second_array.append(date)
    print('first_array:', first_array)
    #print('second_array:', second_array)
    return first_array, second_array

def transfer_gap_date(train_date):
    gap_date = []
    for i in range(len(train_date)):
        gap_date.append((train_date[i] - train_date[0]).days)
    print('gap_data = ', gap_date)
    return gap_date

def flavor_type_sum(gap_date, period, flavor):
    matrix = []
    for i in range(15):
        matrix.append([0]*int((gap_date[-1] + period - 1)/period+1))
    print('matrix:', matrix)
    for i in range(len(flavor)):
        #print('i = ', i)
        if flavor[i] < 16:
            matrix[flavor[i] - 1][int(gap_date[i] / period)] += 1
    #print(matrix)
    return matrix
"""
def predict_flavor(flavor_sum_array, gap_date):
    avg_flavor = []
    sum = 0
    print(flavor_sum_array)
    for i in range(15):
        for j in flavor_sum_array[i]:
            #print(type(j))
            sum += int(j)
        #print(sum)
        sum /= (float)((gap_date[-1] + 2))
        avg_flavor.append(sum)
    print(avg_flavor)
    return avg_flavor
"""

def predict_flavor(flavor_sum_array, eff):
    avg_flavor = []
    sum = 0
    print(flavor_sum_array)
    for i in range(15):
        # for j in flavor_sum_array[i]:
        #     sum += int(j)
        # #print(sum)
        # sum /= (float)((gap_date[-1] + 2))
        tmp_flavor_sum_array = flavor_sum_array[i]
        sum = (float)(tmp_flavor_sum_array[-1]*0.2 + tmp_flavor_sum_array[-2]*0.2 + tmp_flavor_sum_array[-3]*0.17
                      + tmp_flavor_sum_array[-4]*0.13 + tmp_flavor_sum_array[-5]*0.1 + tmp_flavor_sum_array[-6]*0.1
                      + tmp_flavor_sum_array[-7]*0.06 + tmp_flavor_sum_array[-8]*0.04)
        sum = (float)(sum * eff)
        avg_flavor.append(sum)
    print(avg_flavor)
    return avg_flavor


"""
def config_info_pro(ecs_infor_array):
    global flavor_sum_info, flavor_info, opt_type_info, cpu_sum, mem_sum, disk_sum, predict_time_info
    #print(ecs_infor_array[0].split())
    [cpu_sum_tmp, mem_sum_tmp, disk_sum_tmp] = ecs_infor_array[0].split()
    cpu_sum = int(cpu_sum_tmp)
    mem_sum = int(mem_sum_tmp)
    disk_sum = int(disk_sum_tmp)
    flavor_sum_info = int(ecs_infor_array[2])
    for i in ecs_infor_array[3:3+flavor_sum_info]:
        flavor_info.append(int(i[6:8]))
    end_time_tmp = ecs_infor_array[-1]
    end_time_info = datetime.datetime.strptime(end_time_tmp[0:10], '%Y-%m-%d')
    start_time_tmp = ecs_infor_array[-2]
    start_time_info = datetime.datetime.strptime(start_time_tmp[0:10], '%Y-%m-%d')
    predict_time_info = (end_time_info - start_time_info).days
    opt_type_info = ecs_infor_array[-4].strip()
    return
"""


def config_info_pro(ecs_infor_array):
    global flavor_sum_info, flavor_info, opt_type_info, cpu_sum, mem_sum, disk_sum, predict_time_info
    print(ecs_infor_array)
    [cpu_sum_tmp, mem_sum_tmp, disk_sum_tmp] = ecs_infor_array[0].split()
    cpu_sum = int(cpu_sum_tmp)
    mem_sum = int(mem_sum_tmp)
    disk_sum = int(disk_sum_tmp)
    index = 1
    while ecs_infor_array[index] == '\r\n':
        index += 1
    print('index=', index)
    flavor_sum_info = ecs_infor_array[index]
    print(flavor_sum_info)
    print(type(flavor_sum_info))
    flavor_sum_info = int(flavor_sum_info)
    index += 1
    for i in ecs_infor_array[index:index+flavor_sum_info]:
        flavor_info.append(int(i[6:8]))
    index += flavor_sum_info
    while ecs_infor_array[index] == '\r\n':
        index += 1
    opt_type_info = ecs_infor_array[index].strip()
    index += 1
    while ecs_infor_array[index] == '\r\n':
        index += 1
    start_time_tmp = ecs_infor_array[index]
    start_time_info = datetime.datetime.strptime(start_time_tmp[0:10], '%Y-%m-%d')
    index += 1
    end_time_tmp = ecs_infor_array[index]
    end_time_info = datetime.datetime.strptime(end_time_tmp[0:10], '%Y-%m-%d')
    predict_time_info = (end_time_info - start_time_info).days
    return


def flavor_resource(sum_flavor):
    flavor_cpu_resource = 0
    flavor_mem_resource = 0
    for i in range(len(flavor_info)):
        flavor_cpu_resource += sum_flavor[i] * flavor_cpu[i + 1]
        flavor_mem_resource += sum_flavor[i] * flavor_mem[i + 1]
    print(flavor_cpu_resource, flavor_mem_resource)
    return flavor_cpu_resource, flavor_mem_resource

def server_need(flavor_cpu_resource, flavor_mem_resource):
    global cpu_sum, mem_sum, opt_type_info
    if opt_type_info == 'CPU':
        server_num = math.ceil(flavor_cpu_resource/cpu_sum)
        print("server_num:", server_num)
        while server_num * mem_sum < flavor_mem_resource:
            server_num += 1
        return server_num
    if opt_type_info == 'MEM':
        server_num = math.ceil(flavor_mem_resource / mem_sum)
        print("server_num:", server_num)
        while server_num * cpu_sum < flavor_cpu_resource:
            server_num += 1
        return server_num

def is_place_over():
    global sum_flavor
    #print(flavor_info)
    #print(sum_flavor)
    for k in flavor_info[::-1]:
        #print(k)
        if int(sum_flavor[k-1]) > 0:
          return 1
    return 0

def flavor_placing(server_num, cpu_sum , mem_sum ,opt_type):
    global sum_flavor, result
    temp=int(server_num * 15 + 1)
    #print('temp',temp)
    for i in range(temp):
        flag=0
        loop_flag = 1
        full_flag = 1
        count = 0
        tmp_count=[0,0,0,0,0,0,0,0,0,0,0,0,0,0,0]
        str_s = ''
        tmp_cpu_sum = cpu_sum
        tmp_mem_sum = mem_sum
        server_vm_count = ''
        t=is_place_over()
        #print(t)
        if t:  
            while loop_flag:
                for j in flavor_info[::-1]:
                    if full_flag == 0:
                        break
                    for k in flavor_info[::-1]:
                        if tmp_cpu_sum/flavor_cpu[k] > 0 and tmp_mem_sum/flavor_mem[k] > 0:
                            flag=1
                            break
                        else:
                            flag = 0
                    if flag:
                        if sum_flavor[j - 1] > 0 and tmp_cpu_sum >= flavor_cpu[j] and tmp_mem_sum >= flavor_mem[j]:
                            count = 0
                            tmp_cpu_sum = tmp_cpu_sum-flavor_cpu[j]
                            tmp_mem_sum = tmp_mem_sum-flavor_mem[j]
                            print('tmp_cpu_sum = ', tmp_cpu_sum)
                            print('tmp_mem_sum = ', tmp_mem_sum)
                            sum_flavor[j-1] = sum_flavor[j-1]-1
                            tmp_count[j-1] = tmp_count[j-1]+1
                            if is_place_over() == 0:
                               for m in range(len(tmp_count)):
                                 if tmp_count[m] > 0:
                                    str_s = str_s + 'flavor' + str(m+1) + ' ' + str(tmp_count[m]) + ' '
                               result.append(str(i+1)+' '+str_s)
                               return i+1
                        else:
                            count += 1
                            if count >= 15:
                               loop_flag = 0
                               for m in range(len(tmp_count)):
                                  if tmp_count[m] > 0:
                                     str_s = str_s + 'flavor' + str(m+1) + ' ' + str(tmp_count[m]) + ' '
                               result.append(str(i+1)+' '+str_s)
                               break 
                    else:
                        str_s = ''
                        flag = 0
                        loop_flag = 0
                        full_flag = 0
                        print('server %d is full!' % i)
                        for m in range(len(tmp_count)):
                            if tmp_count[m] > 0:
                                 str_s = str_s + 'flavor' + str(m+1) + ' ' + str(tmp_count[m]) + ' '
                        result.append(str(i+1)+' '+str_s)
                        break

        else:
            print("server_num", i)
            return i
    return i



def predict_vm(ecs_lines, input_lines):
    global sum_flavor
    global result,predict_time_info
    sum = 0
    if ecs_lines is None:
        print('ecs information is none')
        return result
    if input_lines is None:
        print('input file information is none')
        return result

    #config_info_pro(ecs_lines)
    config_info_pro(input_lines)
    flavor_info.sort()
    print(cpu_sum, mem_sum, disk_sum, flavor_sum_info, flavor_info, predict_time_info, opt_type_info)
    #[flavor, train_date] = transfer_date(input_lines)
    [flavor, train_date] = transfer_date(ecs_lines)
    gap_date = transfer_gap_date(train_date)
    flavor_sum_array = flavor_type_sum(gap_date, predict_time_info, flavor)
    avg_flavor = predict_flavor(flavor_sum_array, 0.36)  

    sum_flavor = [x * predict_time_info for x in avg_flavor]
    sum_flavor = [int(x) for x in sum_flavor] 
    print (sum_flavor)
    for i in flavor_info:
        sum += sum_flavor[i - 1]
    print (sum)
    #sum=int(sum)
    result.append(str(sum))   
    print(flavor_info)
    str_str=''
    for i in flavor_info:
        i=int(i)
        str_str='flavor'+str(i)+' '+str(int(sum_flavor[i-1]))
        print(str_str)
        result.append('flavor'+str(i)+' '+str(int(sum_flavor[i-1])))  
        #if i == flavor_info[-1]:
           #result.append('\n')
    
    result.append(' ')
    result.append('0')      
    [flavor_cpu_resource, flavor_mem_resource] = flavor_resource(sum_flavor)
    server_num = server_need(flavor_cpu_resource, flavor_mem_resource)
    #print("server_num:", server_num)
    real_server_num = flavor_placing(server_num, cpu_sum,mem_sum,opt_type_info)
    print(real_server_num)
    #real_server_num=int(real_server_num)
    result[flavor_sum_info+2] = str(real_server_num)
    return result
